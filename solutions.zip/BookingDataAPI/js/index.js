var data = [];
var size = 0;
$.ajaxSetup( { "async": false } );
$.getJSON('https://raw.githubusercontent.com/itatsmove/smovechallenge/master/challenges/bookingdata.json',function(json){
	for(var i=0;i<json.length;i++){
		if((json[i].car+1)>size){
			for( var j=size; j<(json[i].car+1); j++ ) {
				  data.push([]);
			}
			size = json[i].car+1;
		}
		data[json[i].car].push(json[i]);
	}
});

function getDateTime(slot){
	var d = Date.parse("Sunday, 26th February 2017 00:00");
	d.addMinutes(15*slot);
	return d;
}
for(var i=0;i<data.length;i++){
	for(var j=0;j<data[i].length;j++){
		data[i][j].start = getDateTime(data[i][j].start+24).toString('MM/dd/yyyy HH:mm');
		data[i][j].end = getDateTime(data[i][j].end+24).toString('MM/dd/yyyy HH:mm');
		data[i][j].label = "Booking id " + data[i][j].id;
		data[i][j].processid = data[i][j].car.toString();
		delete data[i][j].car;
		delete data[i][j].id;
		delete data[i][j].end_location;
		delete data[i][j].start_location;
	}
	$('#car-list').append('<button type="button" class="list-group-item" onclick="generateChart(' + i +');">Car - ' + i + '</button>')
}

function findLabel(i){
	if((i%4)==0){
		return "6 am";
	}else if((i%4)==1){
		return "12 pm";
	}else if((i%4)==2){
		return "6 pm";
	}else{
		return "12 am";
	}
}

function generateCategories(){
	var category = [];
	for(var i=0;i<8;i++){
		var temp = {'start' : getDateTime(i*96).toString('MM/dd/yyyy HH:mm'),
					'end' : getDateTime((i+1)*96).toString('MM/dd/yyyy HH:mm'),
					'label' : getDateTime(i*96).toString('MM/dd/yyyy')};
		category.push(temp);
	}
	var time = [];
	for(var i=0;i<32;i++){
		var temp = {'start' : getDateTime(i*24).toString('MM/dd/yyyy HH:mm'),
					'end' : getDateTime((i+1)*24).toString('MM/dd/yyyy HH:mm'),
					'label' : findLabel(i)};
		time.push(temp);
	}
	return [{"category" : category},{"align" : "right" , "category" : time}];
}

function generateChart(id){
	FusionCharts.ready(function(){	
		var revenueChart = new FusionCharts({
	      "type": "gantt",
	      "renderAt": "chartContainer",
	      "width": "1300",
	      "height": "200",
	      "dataFormat": "json",
	      "dataSource": {
	        "chart": {
	            "caption": "Weekly schedule for Car - " + id,
	            "dateformat": "mm/dd/yyyy",
	            "outputdateformat": "hh:mn",
	        },
            "categories": generateCategories(),
            "processes": {
                "fontsize": "12",
                "isbold": "1",
                "align": "left",
                "headertext": "Car",
                "headerfontsize": "14",
                "headervalign": "middle",
                "headeralign": "left",
                "process": [{
                    "label": "Car " + id.toString(),
                    "id": id.toString()
                }]
            },	        	
        	"tasks" : {
                "showlabels": "1",
                "showstartdate": "1",
                "task": data[id]
        	}
	      }
		});
		revenueChart.render();
	});
}