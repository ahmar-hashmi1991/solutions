var l1 = parseInt($.url().param('l1'));
var l2 = parseInt($.url().param('l2'));
var url = 'https://challenge.smove.sg/availability?startTime=' + l1 + '&endTime=' + l2;
$.getJSON(url,function(data){
	for (var i = 0; i < data.data.length; i++) {
		var row = data.data[i];
		var option1 = $('<option>');
		option1.attr('value', row.id);
		option1.text(row.id + '[' + row.location[0] + ',' + row.location[1] + ']');
		$('select[name="s1"]').append(option1);
	}
});

function getObjects(obj, val) {
    var objects = [];
    for (var i in obj) {
        if (obj[i].id == val) {
            objects.push(obj[i]);
        }
    }
    return objects;
}

$('select[name="s1"]').on('change',function(){
	$.getJSON(url,function(data){		
		var obj = getObjects(data.data,$('select[name="s1"]').val())[0];
		$('input[name="s2"]').val(obj.available_cars);
		$('select[name="s3"]').empty();
		for(var i=0;i<obj.dropoff_locations.length;i++){
			var row = obj.dropoff_locations[i];
			var option1 = $('<option>');
			option1.attr('value', row.id);
			option1.text(row.id + '[' + row.location[0] + ',' + row.location[1] + ']');
			$('select[name="s3"]').append(option1);			
		}
	});
});

function makeBooking(){
	var s1 = parseInt($('select[name="s1"]').val());
	var s2 = parseInt($('input[name="s2"]').val() || '0');
	var s3 = parseInt($('select[name="s3"]').val());
	if(s2==0){
		alert("No car available!");
	}else{
		alert("Booking successful!");
	}
}