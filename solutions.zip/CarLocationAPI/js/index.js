//var map;
var currLat = "", currLong = "";
var markers = [];
var map;
function myMap() {
	var url = 'https://challenge.smove.sg/locations';	
	$.getJSON(url,function(data){
		var totalLat = 0, totalLong = 0;
		for(var i=0;i<data.data.length;i++){
			totalLat += parseFloat(data.data[i].latitude);
			totalLong += parseFloat(data.data[i].longitude);
		}
		var avgLat = totalLat/data.data.length;
		var avgLong = totalLong/data.data.length;
		var mapCanvas = document.getElementById("googleMap");
		var myCenter=new google.maps.LatLng(avgLat, avgLong);
		var mapOptions = {center: myCenter, zoom: 11};
		map = new google.maps.Map(mapCanvas, mapOptions);			
		google.maps.event.addListener(map, 'click', function(event) {
			if(currLat!="" && currLong!=""){
				removeMarker(currLat,currLong);
			}
			currLat = parseFloat(event.latLng.lat());
			currLong = parseFloat(event.latLng.lng());
			placeMarker(currLat,currLong,2);
		});    
	});
}

function findLabel(flag){
	if(flag==0){
		return "V";
	}else if(flag==1){
		return "O";
	}else if(flag==2){
		return "";
//		return "Current";
	}else{
		return "";
	}
}

function findImage(flag){
	if(flag==3){
			return './images/darkgreen_MarkerA.png';
	}
}

function removeMarker(latitude, longitude) {
	for(var i=0;i<markers.length;i++){
		var marker = markers[i];
		if(parseFloat(marker.position.lat())==latitude && parseFloat(marker.position.lng())==longitude)
			marker.setMap(null);
	}
}

function placeMarker(latitude, longitude, flag) {
	var flag1 = 0;
	for(var i=0;i<markers.length;i++){
		//var marker = markers[i];
		if(parseFloat(markers[i].position.lat())==latitude && parseFloat(markers[i].position.lng())==longitude){
			markers[i].label = "";
			markers[i].icon = './images/darkgreen_MarkerA.png';
			flag1 = 1;
			break;
		}
	}
	if(flag1==0){
		var marker = new google.maps.Marker({
			position: {lat: latitude, lng : longitude},
			map: map,
			label: findLabel(flag),
			icon: findImage(flag)
		});
		markers.push(marker);
	}
}

function geoloc(latitude, longitude)
{
    this.latitude=latitude;
    this.longitude=longitude;
}

$('#find-nearest').on('click',function(){
    if (currLat=="" && currLong == "") {
        navigator.geolocation.getCurrentPosition(showPosition, showError);
    }else{
    	var position = {coords : new geoloc(currLat, currLong)};
    	showPosition(position);
    }
});

function showPosition(position) {
    //placeMarker(position.coords.latitude,position.coords.longitude,2);
	var url = 'https://challenge.smove.sg/locations';	
	$.getJSON(url,function(data){
		var min = 100000000;
		var min_index = -1;
		for(var i=0;i<data.data.length;i++){
			var row = data.data[i];
			if(data.data[i].is_on_trip==0){
				var dist = getDistanceFromLatLonInKm(position.coords.latitude,position.coords.longitude,data.data[i].latitude,data.data[i].longitude);
				if(dist<min){
					min = dist;
					min_index = i;
				}
			}
		}
		for(var i = 0; i < data.data.length; i++) {
			if(i!=min_index){
				placeMarker(parseFloat(data.data[i].latitude), parseFloat(data.data[i].longitude), data.data[i].is_on_trip);
			}
		}			
	    	placeMarker(parseFloat(data.data[min_index].latitude),parseFloat(data.data[min_index].longitude),3);		
	});
}	

function getDistanceFromLatLonInKm(lat1,lon1,lat2,lon2) {
	var R = 6371; // Radius of the earth in km
	var dLat = deg2rad(lat2-lat1);  // deg2rad below
	var dLon = deg2rad(lon2-lon1); 
	var a = 
		Math.sin(dLat/2) * Math.sin(dLat/2) +
		Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
		Math.sin(dLon/2) * Math.sin(dLon/2)
		; 
	var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
	var d = R * c; // Distance in km
	return d;
}

function deg2rad(deg) {
  return deg * (Math.PI/180)
}

function showError(error) {
    switch(error.code) {
        case error.PERMISSION_DENIED:
            x.innerHTML = "User denied the request for Geolocation."
            break;
        case error.POSITION_UNAVAILABLE:
            x.innerHTML = "Location information is unavailable."
            break;
        case error.TIMEOUT:
            x.innerHTML = "The request to get user location timed out."
            break;
        case error.UNKNOWN_ERROR:
            x.innerHTML = "An unknown error occurred."
            break;
    }
}

